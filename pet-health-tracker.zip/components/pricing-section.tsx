import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"

const plans = [
  {
    name: "Basic",
    price: "₹499",
    period: "per month",
    description: "Essential health monitoring for your pet",
    features: [
      "Real-time health monitoring",
      "Basic activity tracking",
      "Health alerts",
      "Mobile app access",
      "7-day history",
    ],
    highlighted: false,
    buttonText: "Get Started",
  },
  {
    name: "Premium",
    price: "₹899",
    period: "per month",
    description: "Advanced monitoring with AI insights",
    features: [
      "Everything in Basic",
      "GPS location tracking",
      "Behavior analysis",
      "Vet recommendations",
      "30-day detailed history",
      "Priority customer support",
    ],
    highlighted: true,
    buttonText: "Get Premium",
  },
  {
    name: "Family",
    price: "₹1,499",
    period: "per month",
    description: "Complete care for multiple pets",
    features: [
      "Everything in Premium",
      "Support for up to 4 pets",
      "Family dashboard",
      "Unlimited history",
      "Emergency vet consultations",
      "Personalized health reports",
    ],
    highlighted: false,
    buttonText: "Choose Family",
  },
]

export default function PricingSection() {
  return (
    <section id="pricing" className="py-16 md:py-24 bg-[#FDFDFD]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-[#4A4A4A]">Simple, Transparent Pricing</h2>
          <p className="mt-4 text-lg text-[#4A4A4A]/70 max-w-2xl mx-auto">
            Choose the plan that works best for you and your furry family members. All plans include our core health
            monitoring technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`border ${
                plan.highlighted ? "border-[#B8E7D4] shadow-lg shadow-[#B8E7D4]/20" : "border-[#A7D8F1]/20 shadow-md"
              } hover:shadow-xl transition-shadow duration-300 overflow-hidden`}
            >
              {plan.highlighted && (
                <div className="bg-[#B8E7D4] text-[#4A4A4A] text-center py-2 font-medium">Most Popular</div>
              )}
              <CardHeader className="pt-6 pb-2">
                <h3 className="text-2xl font-bold text-center text-[#4A4A4A]">{plan.name}</h3>
                <div className="text-center mt-4">
                  <span className="text-4xl font-bold text-[#4A4A4A]">{plan.price}</span>
                  <span className="text-[#4A4A4A]/70 ml-1">{plan.period}</span>
                </div>
                <p className="text-center text-[#4A4A4A]/70 mt-2">{plan.description}</p>
              </CardHeader>
              <CardContent className="pt-4">
                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check className="h-5 w-5 text-[#B8E7D4] mr-2 shrink-0 mt-0.5" />
                      <span className="text-[#4A4A4A]/80">{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="pb-6">
                <Button
                  className={`w-full ${
                    plan.highlighted ? "bg-[#B8E7D4] hover:bg-[#B8E7D4]/80" : "bg-[#A7D8F1] hover:bg-[#A7D8F1]/80"
                  } text-[#4A4A4A] transition-colors rounded-full py-6`}
                >
                  {plan.buttonText}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-[#4A4A4A]/70">
            All plans come with a 30-day money-back guarantee. No long-term contracts required.
          </p>
        </div>
      </div>
    </section>
  )
}
